const audio = document.getElementById('audio');
const progress = document.getElementById('progress');
const trackTitle = document.getElementById('track-title');

const tracks = ['audio/track1.mp3','audio/track2.mp3','audio/track3.mp3'];
const titles = ['Track 1','Track 2','Track 3'];
let currentTrack = 0;
let isPlaying = false;

function togglePlay(){
    if(isPlaying){
        audio.pause();
        isPlaying = false;
    } else {
        audio.play();
        isPlaying = true;
    }
}

function nextTrack(){
    currentTrack = (currentTrack + 1) % tracks.length;
    loadTrack();
    audio.play();
    isPlaying = true;
}

function prevTrack(){
    currentTrack = (currentTrack - 1 + tracks.length) % tracks.length;
    loadTrack();
    audio.play();
    isPlaying = true;
}

function loadTrack(){
    audio.src = tracks[currentTrack];
    trackTitle.textContent = titles[currentTrack];
}

audio.addEventListener('timeupdate', () => {
    progress.style.width = (audio.currentTime / audio.duration) * 100 + '%';
});

function seek(event){
    const width = event.currentTarget.clientWidth;
    const clickX = event.offsetX;
    audio.currentTime = (clickX / width) * audio.duration;
}

audio.addEventListener('ended', nextTrack);

// Auto play background music
window.onload = () => {
    audio.play().catch(()=>{});
};
